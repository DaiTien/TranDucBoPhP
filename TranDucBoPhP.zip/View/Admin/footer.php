<footer class="main-footer">
    <strong>Thành Viên FC-Trần Đức Bo :</strong> Trường , Tuấn, Tiến, Lượng
    <div class="float-right d-none d-sm-inline-block">
        <b>IT17A1.11</b>
    </div>
</footer>
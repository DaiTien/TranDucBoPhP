<section class="dishes banner-bg invert invert-black home-icon wow fadeInDown" data-background="asset/web/images/banner1.jpg" data-wow-duration="1000ms" data-wow-delay="300ms">
                    <div class="icon-default icon-black">
                        <img src="asset/web/images/icon5.png" alt="">
                    </div>
                    <div class="container">
                        <div class="build-title">
                            <h2>Trà Sữa Bán Chạy </h2>
                            <h6>BoBo MilkTea "Sữa Thật - Trà Thật".</h6>
                        </div>
                        <div class="slider multiple-items">
                            <div class="product-blog">  
                                <img src="asset/web/images/st-okinawa.png" alt="">
                                <h3>Sữa Tươi Okinawa</h3>
                                <del>35.000 vnd</del><strong class="txt-default">25.000 vnd</strong>
                            </div>
                            <div class="product-blog">
                                <img src="asset/web/images/lt-mango.png" alt="">
                                <h3>Mango Matcha Latte</h3>
                                <del>20.000 vnd</del><strong class="txt-default">12.000 vnd</strong>
                            </div>
                            <div class="product-blog">
                                <img src="asset/web/images/lt-okinawa.png" alt="">
                                <h3>Okinawa Latte</h3>
                                <del>30.000 vnd</del><strong class="txt-default">17.000 vnd</strong>
                            </div>
                            <div class="product-blog">
                                <img src="asset/web/images/lt-strabery.png" alt="">
                                <h3>Strawberry Earl Grey Latte</h3>
                                <del>22.000 vnd</del><strong class="txt-default">15.000 vnd</strong>
                            </div>
                            <div class="product-blog">
                                <img src="asset/web/images/ts-7.png" alt="">
                                <h3>Trà Sữa Trân Châu Đường Đen</h3>
                                <del>$ 55.00</del><strong class="txt-default">35.000 vnd</strong>
                            </div>
                            <div class="product-blog">
                                <img src="asset/web/images/ts-8.png" alt="">
                                <h3>Trà Sữa Khoai Môn</h3>
                                <del>50.000 vnd</del><strong class="txt-default">45.000 vnd</strong>
                            </div>
                        </div>
                    </div>
                </section>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" type="image/png" href="asset/Web/images/favicon.png">
<title>WebSite Trà Sữa Trần Đức Bo</title>
<link href="asset/web/css/bootstrap.css" rel="stylesheet">
<link href="asset/web/css/datepicker.css" rel="stylesheet">
<link href="asset/web/css/font-awesome.css" rel="stylesheet">
<link href="asset/web/css/jquery.formstyler.css" rel="stylesheet">
<link href="asset/web/css/extralayers.css" rel="stylesheet">
<link href="asset/web/css/settings.css" rel="stylesheet">
<link href="asset/web/css/owl.carousel.css" rel="stylesheet">
<link href="asset/web/css/owl.theme.default.css" rel="stylesheet">
<link href="asset/web/css/slick.css" rel="stylesheet">
<link href="asset/web/css/slick-theme.css" rel="stylesheet">
<link href="asset/web/css/magnific-popup.css" rel="stylesheet">
<link href="asset/web/css/jquery.mCustomScrollbar.css" rel="stylesheet">
<link href="asset/web/css/animate.min.css" rel="stylesheet">
<link href="asset/web/css/theme.css" rel="stylesheet">
<link rel="stylesheet" href="asset/web/css/style.css">
<link href="asset/web/css/responsive.css" rel="stylesheet">
<section id="service" class="bg-skeen feature-list text-center home-icon wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
    <div class="icon-default icon-skeen">
        <img src="asset/web/images/icon22.png" alt="">
    </div>
    <div class="container">
        <div class="build-title">
            <h2>Hệ Thống Của Chúng Tôi</h2>
            <h6>The role of a good cook ware in the preparation of a sumptuous meal cannot be <br> over emphasized then one consider white bread</h6>
        </div>
        <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
                <div class="feature-list-icon">
                    <div class="feature-icon-table">
                        <img src="asset/web/images/img9.png" alt="">
                    </div>
                </div>
                <h5>Thức Uống Chất Lượng</h5>
                <p>An toàn, vệ sinh và ngon miệng. Việc sử dụng các nguyên liệu an toàn, tự nhiên và vệ sinh là ưu tiên hàng đầu của Gong Cha. Hương vị tuyệt hảo của các món thức uống là mục đích quan trọng tiếp theo mà chúng tôi muốn hướng đến.</p>
            </div>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <div class="feature-list-icon">
                    <div class="feature-icon-table">
                        <img src="asset/web/images/img10.png" alt="">
                    </div>
                </div>
                <h5>Menu Đa Dạng</h5>
                <p>Menu Đa Dạng để khách hàng lựa chọn nhiều thức uống, Các món thức uống siêu hấp dẫn
                    giành cho khách hàng từ mọi lứa tuổi .
                </p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
                <div class="feature-list-icon">
                    <div class="feature-icon-table">
                        <img src="asset/web/images/img11.png" alt="">
                    </div>
                </div>
                <h5>Phục Vụ Chuyên Nghiệp</h5>
                <p>BoBo MilkTea mong muốn làm hài lòng khách hàng tốt nhất với tác phong phục vụ chuyên nghiệp và thân thiện, luôn lắng nghe những đóng góp của khách hàng.</p>
            </div>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <div class="feature-list-icon">
                    <div class="feature-icon-table">
                        <img src="asset/web/images/img12.png" alt="">
                    </div>
                </div>
                <h5>Giao Hàng Nhanh Chóng</h5>
                <p>Dựa trên hai nền tảng cốt lõi là Chất Lượng và Dịch Vụ, BoBo MilkTea luôn nỗ lực xây dựng và duy trì hình ảnh thương hiệu đáng tin cậy trong mắt khách hàng.</p>
            </div>
        </div>
    </div>
</section>